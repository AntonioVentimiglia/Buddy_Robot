# config

Diagnostics config.
